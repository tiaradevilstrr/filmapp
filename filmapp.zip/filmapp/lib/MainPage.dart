import 'package:flutter/material.dart';
import 'package:filmapp/MyFunction.dart';

class MySecond extends StatelessWidget {
  const MySecond({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text("Aplikasi 21 Cinema"),
      ),
      body: ListView(
        children: [
          MyDescription(lebar, "Avengers : Endgame", "assets/endgame.jpg"),
          MyDescription(lebar, "The Batman 2022", "assets/batman.jpg"),
          MyDescription(lebar, " Spider-Man : Far From Home", "assets/far.jpg"),
          MyDescription(lebar, "Spider-Man : No Way Home", "assets/way.jpg"),
          MyDescription(lebar, "The King's Man 2022", "assets/kingsman.jpg"),
          MyDescription(lebar, "The Exorcism God", "assets/exorcism.jpg"),
          MyDescription(lebar, "Fast 9", "assets/f9.jpg"),
          MyDescription(lebar, "The Contractor 2022", "assets/contractor.jpg"),
          MyDescription(lebar, "The Rescue 2021", "assets/rescue.jpg"),
        ],
      ),
      backgroundColor: Colors.amber,
    );
  }
}
