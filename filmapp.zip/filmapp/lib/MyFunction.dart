import 'package:flutter/material.dart';

Widget MyFilm(String pictureName) {
  return Container(
    margin: EdgeInsets.only(
      left: 10,
    ),
    width: 170,
    height: 230,
    decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage(pictureName),
        ),
        borderRadius: BorderRadius.circular(40)),
  );
}

Widget MyDescription(var widthWidget, String description, String gambar) {
  return Container(
    child: Row(
      children: [
        Container(
          margin: EdgeInsets.only(
            top: 20,
          ),
          width: widthWidget,
          height: 100,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(25),
          ),
          child: Row(
            children: [
              Container(
                margin: EdgeInsets.only(left: 13),
                width: 60,
                height: 80,
                decoration: BoxDecoration(
                    image: DecorationImage(
                  image: AssetImage(gambar),
                )),
              ),
              Container(
                margin: EdgeInsets.only(top: 10, left: 5),
                child: Text(
                  description,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}
