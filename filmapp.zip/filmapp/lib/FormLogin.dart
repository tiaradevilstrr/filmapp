import 'package:flutter/material.dart';

class MyBuy extends StatefulWidget {
  const MyBuy({Key? key}) : super(key: key);

  @override
  State<MyBuy> createState() => _MyBuyState();
}

class _MyBuyState extends State<MyBuy> {
  String namaDepan = "-", namaBelakang = "-";
  String alamat = "-";
  String tipe = "-";

  final frontName = TextEditingController();
  final backName = TextEditingController();
  final address = TextEditingController();
  final genre = TextEditingController();

  @override
  void dispose() {
    frontName.dispose();
    backName.dispose();
    address.dispose();
    genre.dispose();
    super.dispose();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Aplikasi 21 Cinema"),
      ),
      body: ListView(
        children: [
          Center(
            child: Text(
              "Infromasi Data Pembelian",
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Divider(),
          Text(
            "Nama Lengkap : ${namaDepan} ${namaBelakang}",
            style: TextStyle(fontSize: 20),
          ),
          Divider(),
          Text(
            "Alamat Email : ${alamat}",
            style: TextStyle(fontSize: 20),
          ),
          Divider(),
          Text(
            "Judul Film : ${tipe}",
            style: TextStyle(
              fontSize: 20,
            ),
          ),
          Divider(),
          Text(
              "---------------------------------------------------------------------------------------------------"),
          Divider(),
          Text(
            "Masukkan Nama Depan :",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          Divider(),
          TextField(
            controller: frontName,
            decoration: InputDecoration(
                border: OutlineInputBorder(), label: Text("Nama Depan")),
          ),
          Divider(),
          TextField(
            controller: backName,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              label: Text("Nama Belakang"),
            ),
          ),
          Divider(),
          TextField(
            controller: address,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              label: Text("Masukkan Alamat Email"),
            ),
          ),
          Divider(),
          TextField(
            controller: genre,
            decoration: InputDecoration(
                border: OutlineInputBorder(),
                label: Text("Masukkan Judul Film")),
          ),
          Divider(),
          ElevatedButton(
              onPressed: () {
                setState(() {
                  namaDepan = frontName.text;
                  namaBelakang = backName.text;
                  alamat = address.text;
                  tipe = genre.text;
                });
              },
              child: Text("Tampilkan Data"))
        ],
      ),
    );
  }
}
