import 'package:flutter/material.dart';
import 'package:filmapp/MainPage.dart';
import 'package:filmapp/MyFunction.dart';
import 'package:filmapp/FormLogin.dart';

class MyHome extends StatefulWidget {
  const MyHome({Key? key}) : super(key: key);

  @override
  State<MyHome> createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Aplikasi Postest 3 Rahmat"),
      ),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 20, left: 25, bottom: 15),
            child: Text(
              "Trending",
              style: TextStyle(
                fontSize: 20,
              ),
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                MyFilm("assets/far.jpg"),
                MyFilm("assets/noway.jpg"),
                MyFilm("assets/strange.jpg"),
                MyFilm("assets/ironman3.jpg"),
                MyFilm("assets/endgame.jpg"),
                MyFilm("assets/iron3.jpg"),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(
              top: 30,
              left: 25,
              bottom: 15,
            ),
            child: Text(
              "Unggulan",
              style: TextStyle(
                fontSize: 20,
              ),
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                MyFilm("assets/moonfal.jpg"),
                MyFilm("assets/contractor.jpg"),
                MyFilm("assets/f9.jpg"),
                MyFilm("assets/rescue.jpg"),
                MyFilm("assets/yaksha.jpg"),
                MyFilm("assets/kingsman.jpg")
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 30, left: 25, bottom: 15),
            child: Text(
              "Terbaru",
              style: TextStyle(fontSize: 20),
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                MyFilm("assets/batman.jpg"),
                MyFilm("assets/cell.jpg"),
                MyFilm("assets/exorcism.jpg"),
                MyFilm("assets/jazzy.jpg"),
                MyFilm("assets/nights.jpg"),
                MyFilm("assets/storm.jpg"),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.all(30),
            child: ElevatedButton(
              child: Text("View In List"),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MySecond()),
                );
              },
            ),
          )
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            DrawerHeader(
              child: Text(
                "Apllication Menu",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.person),
              title: Text("Form pembelian"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) {
                    return MyBuy();
                  }),
                );
              },
            )
          ],
        ),
      ),
    );
  }
}
